Folder location for any custom global assets. Assets located in this folder can be accessed in the theme by using the 'assets/' file path.
